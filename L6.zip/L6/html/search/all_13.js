var searchData=
[
  ['x',['x',['../struct_point.html#ab99c56589bc8ad5fa5071387110a5bc7',1,'Point::x()'],['../l6q1_8cpp.html#a6150e0515f7202e2fb518f7206ed97dc',1,'x():&#160;l6q1.cpp'],['../l6q2_8cpp.html#a6150e0515f7202e2fb518f7206ed97dc',1,'x():&#160;l6q2.cpp']]]
];
