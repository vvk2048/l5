var searchData=
[
  ['front',['front',['../structqueue.html#a6c50c7c8bcd9c5962996ed8b1be8771c',1,'queue']]]
];
