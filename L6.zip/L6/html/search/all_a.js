var searchData=
[
  ['next',['next',['../structnode.html#aa3e8aa83f864292b5a01210f4453fcc0',1,'node']]],
  ['node',['Node',['../struct_node.html',1,'Node'],['../structnode.html',1,'node']]],
  ['nodeptr',['nodeptr',['../l6q1_8cpp.html#a940c603ef28546fa4f0b7faf38c824c0',1,'l6q1.cpp']]]
];
