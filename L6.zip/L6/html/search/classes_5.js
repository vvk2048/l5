var searchData=
[
  ['stack',['stack',['../structstack.html',1,'']]]
];
