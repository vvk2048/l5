var searchData=
[
  ['line',['Line',['../struct_line.html#a549d53aa564e20ba316c241f4938254b',1,'Line::Line(const Line &amp;b)'],['../struct_line.html#acd6e6638a77890435f82abb1e666dd25',1,'Line::Line(const Point &amp;_beg, const Point &amp;_end)']]],
  ['linearfitline',['linearfitline',['../l6q3_8cpp.html#afeefc4b0befb61aa570a24d552271099',1,'l6q3.cpp']]]
];
