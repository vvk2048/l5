var searchData=
[
  ['test_5fcase',['test_case',['../l6q3_8cpp.html#a43c56fad8016322388d98e481011b55d',1,'l6q3.cpp']]],
  ['tst2',['tst2',['../l6q3_8cpp.html#adfd5410236ad868511398c69354f7bfd',1,'l6q3.cpp']]]
];
