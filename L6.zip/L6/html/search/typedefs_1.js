var searchData=
[
  ['nodeptr',['nodeptr',['../l6q1_8cpp.html#a940c603ef28546fa4f0b7faf38c824c0',1,'l6q1.cpp']]]
];
