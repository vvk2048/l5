var searchData=
[
  ['beg',['beg',['../struct_line.html#a1a2e587cf1378a7cb7eb66a80065f226',1,'Line']]]
];
