var searchData=
[
  ['child',['child',['../struct_node.html#a1124b77881c051aee791e949376f82e2',1,'Node']]]
];
