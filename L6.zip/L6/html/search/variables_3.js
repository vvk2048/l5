var searchData=
[
  ['degree',['degree',['../struct_node.html#a59f29d98e3085ab7fa44197905316061',1,'Node']]]
];
