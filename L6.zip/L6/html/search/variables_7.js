var searchData=
[
  ['next',['next',['../structnode.html#aa3e8aa83f864292b5a01210f4453fcc0',1,'node']]]
];
