var searchData=
[
  ['parent',['parent',['../struct_node.html#ad8184598cdea70e4bbdfd76f2b0f9e85',1,'Node']]]
];
