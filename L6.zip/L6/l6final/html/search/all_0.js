var searchData=
[
  ['arr',['arr',['../structqueue.html#a944ac1b273b836bc1cbc99d5374f919b',1,'queue::arr()'],['../structstack.html#aec382a433db8ef5645d6587145a3b6b6',1,'stack::arr()']]]
];
