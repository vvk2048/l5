#include <bits/stdc++.h> 
using namespace std; 

int x=0;
// Structure of Node 
/** 
*@author k.vivek veman 18114037
*@date oct 8,2019
* Structure of Node 
*/ 

struct Node 
{ 
	int val, degree; 
	Node *parent, *child, *sister; 
}; 



// Making root global to avoid one extra 
// parameter in all functions. 
Node *root = NULL; 

// 
// of h2. 
/** 
*@author k.vivek veman 18114037
*@date oct 8,2019
* link two heaps by making h1 a child 
*/
void binomialLink(Node *h1, Node *h2) 
{ 
	h1->parent = h2; 
	h1->sister = h2->child; 
	h2->child = h1; 
	h2->degree = h2->degree + 1; 
} 
/** 
*@author k.vivek veman 18114037
*@date oct 8,2019
* create a Node 
*/
//
Node *createNode(int n) 
{ 
	Node *new_node = new Node; 
	new_node->val = n; 
	new_node->parent = NULL; 
	new_node->sister = NULL; 
	new_node->child = NULL; 
	new_node->degree = 0; 
	return new_node; 
} 
/** 
*@author k.vivek veman 18114037
*@date oct 8,2019
* This function merge two Binomial Trees 
*/
// 
Node *mergeBHeaps(Node *h1, Node *h2) 
{ 
	if (h1 == NULL) 
		return h2; 
	if (h2 == NULL) 
		return h1; 

	// define a Node 
	Node *res = NULL; 

	// check degree of both Node i.e. 
	// which is greater or smaller 
	if (h1->degree <= h2->degree) 
		res = h1; 

	else if (h1->degree > h2->degree) 
		res = h2; 

	// traverse till if any of heap gets empty 
	while (h1 != NULL && h2 != NULL) 
	{ 
		// if degree of h1 is smaller, increment h1 
		if (h1->degree < h2->degree) 
			h1 = h1->sister; 

		// Link h1 with h2 in case of equal degree 
		else if (h1->degree == h2->degree) 
		{ 
			Node *sib = h1->sister; 
			h1->sister = h2; 
			h1 = sib; 
		} 

		// if h2 is greater 
		else
		{ 
			Node *sib = h2->sister; 
			h2->sister = h1; 
			h2 = sib; 
		} 
	} 
	return res; 
} 
/** 
*@author k.vivek veman 18114037
*@date oct 8,2019
* This function perform union operation on two 
*/

// 
// binomial heap i.e. h1 & h2 
Node *unionBHeaps(Node *h1, Node *h2) 
{ 
	if (h1 == NULL && h2 == NULL) 
	return NULL; 

	Node *res = mergeBHeaps(h1, h2); 

	// Traverse the merged list and set 
	// values according to the degree of 
	// Nodes 
	Node *prev = NULL, *curr = res, *next = curr->sister; 

	while (next != NULL) 
	{ 
		if ((curr->degree != next->degree) || 
				((next->sister != NULL) && 
				(next->sister)->degree == 
				curr->degree)) 
		{ 
			prev = curr; 
			curr = next; 
		} 

		else
		{ 
			if (curr->val <= next->val) 
			{ 
				curr->sister = next->sister; 
				binomialLink(next, curr); 
			} 
			else
			{ 
				if (prev == NULL) 
					res = next; 
				else
					prev->sister = next; 
				binomialLink(curr, next); 
				curr = next; 
			} 
		} 
		next = curr->sister; 
	} 
	return res; 
} 
/** 
*@author k.vivek veman 18114037
*@date oct 8,2019
* Function to insert a Node 
*/
ofstream outdata;
// 
void binomialHeapInsert(int x) 
{ 
	// Create a new node and do union of 
	// this node with root 
	root = unionBHeaps(root, createNode(x)); 
} 
/** 
*@author k.vivek veman 18114037
*@date oct 8,2019
* Function to print_function the Nodes 
*/
// 
void print_function(Node *h) 
{ 
	while (h) 
	{   

        if(x<h->degree){
            x=h->degree;
            cout<<endl<<"Order "<<x<<": ";
            if(!h->child) 
            outdata<<h->val<<";"<<endl;
        }

        if(h->child){
            outdata<<h->val<<"--"<<h->child->val<<";"<<endl;
            
            if(h->child->sister){
            outdata<<h->val<<"--"<<h->child->sister->val<<";"<<endl;
            }
        }
        
        
        
		cout << h->val<<" ";
		print_function(h->child);
        //cout<<"yo"<<endl; 
        
        
		h = h->sister;
	} 
} 

/** 
*@author k.vivek veman 18114037
*@date oct 8,2019
*/
// Driver code 
int main() 
{ 
	// Note that root is global 
    //cout<<bin(9)<<endl;
    outdata.open("C:\\Users\\VIVEK VEMAN KARNATI\\Desktop\\common.dot");

    if( !outdata ) {
        cerr << "Error: file could not be opened" << endl;
        exit(1);
    }
    outdata<<"graph{"<<endl;
int j,k,ja;
	cin>>j;
while(j--){cin>>k;
	binomialHeapInsert(k);}

	
    
    x=root->degree;
    if(!root->child)
    outdata<<root->val<<";"<<endl;
	cout << "The heap is:\nOrder "<<x<<": "; 
	print_function(root); 
    outdata<<"}"<<endl;
    cout<<endl;
    outdata.close();
	return 0; 
}